# Changelog

See the [Releases](https://github.com/FairwindsOps/goldilocks/releases) page for relevant changes.
